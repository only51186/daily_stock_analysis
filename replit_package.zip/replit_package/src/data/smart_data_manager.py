# -*- coding: utf-8 -*-
"""
===================================
智能数据管理器 (Smart Data Manager)
===================================

【核心功能】
1. 基于时间的数据获取策略（15:00前后）
2. 自动检查数据存在性，避免重复下载
3. 智能数据更新和缓存管理
4. 统一数据访问接口

【时间策略】
- 15:00之前：使用昨天数据
- 15:00之后：使用当天数据
- 每次数据调用前检查数据存在性

【调用方式】
```python
from src.data.smart_data_manager import SmartDataManager

# 创建智能数据管理器
smart_dm = SmartDataManager()

# 智能获取股票数据（自动判断日期）
data = smart_dm.get_smart_stock_daily()

# 智能获取因子数据
factor_data = smart_dm.get_smart_factor_data()
```
"""

import logging
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional

import pandas as pd

logger = logging.getLogger(__name__)


class SmartDataManager:
    """
    智能数据管理器
    
    功能：
    1. 基于时间的数据获取策略
    2. 自动检查数据存在性
    3. 智能数据更新
    """
    
    def __init__(self, db_path: Optional[str] = None):
        """
        初始化智能数据管理器
        
        Args:
            db_path: 数据库路径（可选）
        """
        if db_path is None:
            project_root = Path(__file__).parent.parent.parent
            self.db_path = project_root / 'data' / 'stock_data.db'
        else:
            self.db_path = Path(db_path)
        
        self.conn = None
        logger.info(f"智能数据管理器初始化完成，数据库: {self.db_path}")
    
    def connect(self):
        """
        连接数据库（线程安全）
        """
        if self.conn:
            try:
                self.conn.close()
            except:
                pass
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
    
    def _should_download_today_data(self) -> bool:
        """
        判断是否需要下载当天数据
        
        Returns:
            bool: True表示需要下载当天数据，False表示使用昨天数据
        """
        current_time = datetime.now()
        current_hour = current_time.hour
        
        # 15:00之后才下载当天数据
        if current_hour >= 15:
            logger.info(f"当前时间 {current_time.strftime('%H:%M')}，需要下载当天数据")
            return True
        else:
            logger.info(f"当前时间 {current_time.strftime('%H:%M')}，使用昨天数据")
            return False
    
    def _get_target_date(self) -> str:
        """
        获取目标日期（根据时间决定是今天还是昨天）
        
        Returns:
            str: 目标日期字符串
        """
        current_time = datetime.now()
        
        if self._should_download_today_data():
            target_date = current_time.strftime('%Y-%m-%d')
        else:
            # 如果是15:00之前，使用昨天数据
            yesterday = current_time - timedelta(days=1)
            target_date = yesterday.strftime('%Y-%m-%d')
        
        logger.info(f"目标日期: {target_date}")
        return target_date
    
    def _check_data_exists(self, date: str) -> bool:
        """
        检查指定日期数据是否存在
        
        Args:
            date: 日期字符串
            
        Returns:
            bool: 数据是否存在
        """
        self.connect()
        cursor = self.conn.cursor()
        
        try:
            cursor.execute('SELECT COUNT(*) FROM stock_daily WHERE date = ?', (date,))
            count = cursor.fetchone()[0]
            
            exists = count > 0
            logger.info(f"日期 {date} 数据存在性检查: {'存在' if exists else '不存在'} ({count}条)")
            return exists
            
        except Exception as e:
            logger.warning(f"检查日期 {date} 数据存在性失败: {e}")
            return False
    
    def get_stock_daily(self, date: Optional[str] = None, limit: Optional[int] = None) -> pd.DataFrame:
        """
        获取股票日线数据
        
        Args:
            date: 日期（可选）
            limit: 返回条数限制（可选）
            
        Returns:
            股票日线数据DataFrame
        """
        self.connect()
        cursor = self.conn.cursor()
        
        query = 'SELECT * FROM stock_daily WHERE 1=1'
        params = []
        
        if date:
            query += ' AND date = ?'
            params.append(date)
        
        query += ' ORDER BY date DESC'
        
        if limit:
            query += ' LIMIT ?'
            params.append(limit)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        if rows:
            df = pd.DataFrame(rows)
            columns = [desc[0] for desc in cursor.description]
            df.columns = columns
            return df
        else:
            return pd.DataFrame()
    
    def get_smart_stock_daily(self, limit: Optional[int] = None) -> pd.DataFrame:
        """
        智能获取股票日线数据
        
        Args:
            limit: 返回条数限制（可选）
            
        Returns:
            股票日线数据DataFrame
        """
        target_date = self._get_target_date()
        
        # 检查目标日期数据是否存在
        if self._check_data_exists(target_date):
            logger.info(f"✅ 目标日期 {target_date} 数据已存在，直接使用")
            return self.get_stock_daily(date=target_date, limit=limit)
        else:
            logger.warning(f"⚠️ 目标日期 {target_date} 数据不存在，需要下载")
            
            # 如果目标日期是今天且需要下载，则触发下载
            if self._should_download_today_data() and target_date == datetime.now().strftime('%Y-%m-%d'):
                logger.info(f"📥 触发当天数据下载: {target_date}")
                
                # 导入数据下载模块
                try:
                    from scripts.auto_data_downloader import AutoDataDownloader
                    downloader = AutoDataDownloader()
                    result = downloader.download_all_data(force=True)
                    
                    if result.get('stocks', {}).get('success', False):
                        logger.info(f"✅ 当天数据下载成功: {result['stocks']['count']}只股票")
                        return self.get_stock_daily(date=target_date, limit=limit)
                    else:
                        logger.error("❌ 当天数据下载失败")
                        # 下载失败时尝试使用昨天数据
                        yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
                        return self.get_stock_daily(date=yesterday, limit=limit)
                        
                except Exception as e:
                    logger.error(f"❌ 数据下载失败: {e}")
                    # 下载失败时尝试使用昨天数据
                    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
                    return self.get_stock_daily(date=yesterday, limit=limit)
            else:
                # 如果是历史数据不存在，尝试使用最新可用数据
                latest_date = self.get_latest_date()
                if latest_date:
                    logger.info(f"📊 使用最新可用数据: {latest_date}")
                    return self.get_stock_daily(date=latest_date, limit=limit)
                else:
                    logger.error("❌ 无可用数据")
                    return pd.DataFrame()
    
    def get_latest_date(self) -> Optional[str]:
        """
        获取最新数据日期
        
        Returns:
            最新日期字符串
        """
        self.connect()
        cursor = self.conn.cursor()
        
        cursor.execute('SELECT MAX(date) FROM stock_daily')
        result = cursor.fetchone()
        
        if result and result[0]:
            return result[0]
        else:
            return None
    
    def get_factor_data(self, code: Optional[str] = None, date: Optional[str] = None) -> pd.DataFrame:
        """
        获取因子数据
        
        Args:
            code: 股票代码（可选）
            date: 日期（可选）
            
        Returns:
            因子数据DataFrame
        """
        self.connect()
        cursor = self.conn.cursor()
        
        query = 'SELECT * FROM factor_data WHERE 1=1'
        params = []
        
        if code:
            query += ' AND code = ?'
            params.append(code)
        
        if date:
            query += ' AND date = ?'
            params.append(date)
        
        query += ' ORDER BY date DESC'
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        if rows:
            df = pd.DataFrame(rows)
            columns = [desc[0] for desc in cursor.description]
            df.columns = columns
            return df
        else:
            return pd.DataFrame()
    
    def get_smart_factor_data(self, code: Optional[str] = None, date: Optional[str] = None) -> pd.DataFrame:
        """
        智能获取因子数据
        
        Args:
            code: 股票代码（可选）
            date: 日期（可选，如不指定则使用智能日期）
            
        Returns:
            因子数据DataFrame
        """
        if date is None:
            date = self._get_target_date()
        
        return self.get_factor_data(code=code, date=date)


# 全局智能数据管理器实例
_smart_data_manager_instance = None

def get_smart_data_manager() -> SmartDataManager:
    """
    获取智能数据管理器单例
    
    Returns:
        SmartDataManager实例
    """
    global _smart_data_manager_instance
    if _smart_data_manager_instance is None:
        _smart_data_manager_instance = SmartDataManager()
    return _smart_data_manager_instance