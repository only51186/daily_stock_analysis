# -*- coding: utf-8 -*-
"""
===================================
Tushare 权限规则说明
===================================

【Tushare Pro 120 积分权限规则】

1. 积分说明
   - 120 积分是 Tushare 的基础免费准入门槛
   - 无需捐助即可获得
   - 注册账号后自动获得 120 积分

2. 调用限制
   - 每分钟最多 50 次调用
   - 每天累计最多 8000 次调用

3. 核心限制（重要）
   - 仅能调取「股票非复权日线行情」这一个接口
   - 接口名称：daily（日线行情）
   - 其他所有接口均无法调取，包括但不限于：
     * trade_cal（交易日历）
     * daily_basic（每日指标）
     * moneyflow（资金流向）
     * top_list（龙虎榜）
     * income（财务数据）
     * balance（资产负债表）
     * cashflow（现金流量表）
     * 等等...

4. 权限提升建议
   - 如需使用更多接口，建议提升 Tushare 积分
   - 捐助或参与活动可获得更高积分
   - 更高积分可解锁更多接口和更高的调用频率

5. 备用数据源
   - Akshare：无积分门槛，免费使用
   - Efinance：无积分门槛，免费使用
   - 建议在 Tushare 权限不足时自动切换到备用数据源

【系统使用建议】

1. 当前配置
   - 数据源优先级：akshare → efinance → tushare
   - Tushare 仅作为备用数据源

2. 适用场景
   - Tushare 120积分：仅适用于获取基础日线行情数据
   - Akshare/Efinance：适用于获取完整的市场数据（换手率、量比、资金流向等）

3. 权限提示
   - 当系统尝试调用 Tushare 的受限接口时，会自动提示权限限制
   - 自动切换到 Akshare 等备用数据源
   - 确保系统正常运行

【接口对照表】

| 功能 | Tushare 120积分 | Akshare | Efinance |
|:---|:---:|:---:|:---:|
| 日线行情 | ✅ | ✅ | ✅ |
| 实时行情 | ❌ | ✅ | ✅ |
| 换手率 | ❌ | ✅ | ✅ |
| 量比 | ❌ | ✅ | ✅ |
| 资金流向 | ❌ | ✅ | ✅ |
| 龙虎榜 | ❌ | ✅ | ✅ |
| 财务数据 | ❌ | ✅ | ✅ |
| 板块数据 | ❌ | ✅ | ✅ |

【注意事项】

1. 系统已配置自动切换机制，Tushare 权限不足时自动使用 Akshare
2. 建议优先使用 Akshare 数据源，数据更完整且无限制
3. 如需提升 Tushare 权限，请访问：https://tushare.pro/document/1?doc_id=108
"""

TUSHARE_120_POINTS_RULES = {
    'points': 120,
    'description': '基础免费准入门槛',
    'donation_required': False,
    'rate_limit': {
        'per_minute': 50,
        'per_day': 8000
    },
    'allowed_interfaces': [
        'daily'  # 股票非复权日线行情
    ],
    'restricted_interfaces': [
        'trade_cal',      # 交易日历
        'daily_basic',     # 每日指标
        'moneyflow',       # 资金流向
        'top_list',        # 龙虎榜
        'income',          # 利润表
        'balance',         # 资产负债表
        'cashflow',        # 现金流量表
        'fina_indicator',  # 财务指标
        'margin',         # 融资融券
        'short',          # 沪深港通
        # ... 其他接口
    ]
}


def check_tushare_permission(interface_name: str) -> tuple[bool, str]:
    """
    检查 Tushare 接口是否在 120 积分权限范围内
    
    Args:
        interface_name: 接口名称
        
    Returns:
        (是否允许, 提示信息)
    """
    if interface_name in TUSHARE_120_POINTS_RULES['allowed_interfaces']:
        return True, "✅ 接口在权限范围内"
    else:
        return False, f"⚠️ 接口 '{interface_name}' 不在 Tushare 120 积分权限范围内，建议使用 Akshare 备用数据源"


def get_tushare_suggestion(interface_name: str) -> str:
    """
    获取 Tushare 权限不足时的建议
    
    Args:
        interface_name: 接口名称
        
    Returns:
        建议信息
    """
    allowed, message = check_tushare_permission(interface_name)
    
    if allowed:
        return message
    else:
        suggestion = f"""
{message}

Tushare 120 积分权限限制：
- 仅能调取「股票非复权日线行情」接口
- 其他接口（包括 {interface_name}）无法调取

解决方案：
1. 使用 Akshare 备用数据源（推荐，无限制）
2. 提升 Tushare 积分以解锁更多接口
   访问：https://tushare.pro/document/1?doc_id=108
"""
        return suggestion


if __name__ == '__main__':
    print(__doc__)
    
    # 测试权限检查
    print("\n" + "=" * 80)
    print("权限检查测试")
    print("=" * 80)
    
    test_interfaces = ['daily', 'trade_cal', 'daily_basic', 'moneyflow', 'top_list']
    
    for interface in test_interfaces:
        allowed, message = check_tushare_permission(interface)
        status = "✅ 允许" if allowed else "❌ 限制"
        print(f"\n{interface:20s} - {status}")
        if not allowed:
            print(get_tushare_suggestion(interface))
