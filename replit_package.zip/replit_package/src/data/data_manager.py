# -*- coding: utf-8 -*-
"""
===================================
数据管理器 (Data Manager)
===================================

【核心功能】
1. 统一管理SQLite数据库连接
2. 提供数据存储和查询接口
3. 线程安全的数据访问
4. 数据完整性校验

【数据库表结构】
- stock_daily: 股票日线数据
- factor_data: 因子数据
- selection_results: 选股结果
- backtest_results: 回测结果
- review_data: 复盘数据
"""

import logging
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List

import pandas as pd

logger = logging.getLogger(__name__)


class DataManager:
    """
    数据管理器
    
    功能：
    1. 管理数据库连接
    2. 提供数据存储和查询接口
    3. 确保线程安全
    """
    
    def __init__(self, db_path: Optional[str] = None):
        """
        初始化数据管理器
        
        Args:
            db_path: 数据库路径（可选）
        """
        if db_path is None:
            project_root = Path(__file__).parent.parent.parent
            self.db_path = project_root / 'data' / 'stock_data.db'
        else:
            self.db_path = Path(db_path)
        
        # 确保数据目录存在
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.conn = None
        self._init_database()
        logger.info(f"数据管理器初始化完成，数据库路径: {self.db_path}")
    
    def _init_database(self):
        """
        初始化数据库表结构
        """
        self.connect()
        cursor = self.conn.cursor()
        
        # 股票日线数据表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stock_daily (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL,
                name TEXT,
                date TEXT NOT NULL,
                open REAL,
                high REAL,
                low REAL,
                close REAL,
                volume REAL,
                amount REAL,
                pct_chg REAL,
                turnover REAL,
                volume_ratio REAL,
                circ_mv REAL,
                total_mv REAL,
                amplitude REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(code, date)
            )
        ''')
        
        # 因子数据表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS factor_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL,
                date TEXT NOT NULL,
                ma5 REAL,
                ma10 REAL,
                ma20 REAL,
                ma60 REAL,
                macd_dif REAL,
                macd_dea REAL,
                macd_hist REAL,
                rsi REAL,
                boll_up REAL,
                boll_mid REAL,
                boll_down REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(code, date)
            )
        ''')
        
        # 选股结果表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS selection_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL,
                name TEXT,
                date TEXT NOT NULL,
                close REAL,
                pct_chg REAL,
                turnover REAL,
                volume_ratio REAL,
                circ_mv REAL,
                amount REAL,
                strategy_name TEXT,
                score REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(code, date, strategy_name)
            )
        ''')
        
        # 回测结果表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS backtest_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                strategy_name TEXT NOT NULL,
                total_trades INTEGER,
                win_trades INTEGER,
                loss_trades INTEGER,
                win_rate REAL,
                total_return REAL,
                annualized_return REAL,
                max_drawdown REAL,
                sharpe_ratio REAL,
                profit_loss_ratio REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(date, strategy_name)
            )
        ''')
        
        # 复盘数据表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS review_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                up_count INTEGER,
                down_count INTEGER,
                flat_count INTEGER,
                avg_pct_chg REAL,
                total_amount REAL,
                hot_sectors TEXT,
                capital_flow REAL,
                limit_up_count INTEGER,
                limit_down_count INTEGER,
                market_sentiment TEXT,
                trading_advice TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(date)
            )
        ''')
        
        self.conn.commit()
        logger.info("数据库表结构初始化完成")
    
    def connect(self):
        """
        连接数据库（线程安全版本）
        """
        if self.conn:
            try:
                self.conn.close()
            except:
                pass
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
    
    def close(self):
        """
        关闭数据库连接
        """
        if self.conn:
            self.conn.close()
            self.conn = None
    
    def save_stock_daily(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        保存股票日线数据
        
        Args:
            df: 股票日线数据DataFrame
            
        Returns:
            保存结果统计
        """
        if df.empty:
            return {'success': False, 'message': '数据为空'}
        
        self.connect()
        cursor = self.conn.cursor()
        
        try:
            # 数据清洗
            df = df.copy()
            
            # 确保必要列存在
            required_cols = ['code', 'date', 'close']
            for col in required_cols:
                if col not in df.columns:
                    logger.warning(f"缺少必要列: {col}")
                    return {'success': False, 'message': f'缺少必要列: {col}'}
            
            # 转换日期格式
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
            
            # 处理缺失列
            save_columns = ['code', 'name', 'date', 'open', 'high', 'low', 'close', 
                          'volume', 'amount', 'pct_chg', 'turnover', 
                          'volume_ratio', 'circ_mv', 'total_mv', 'amplitude']
            
            df_to_save = pd.DataFrame()
            for col in save_columns:
                if col in df.columns:
                    df_to_save[col] = df[col]
                else:
                    df_to_save[col] = None
            
            # 批量插入
            df_to_save.to_sql('stock_daily', self.conn, if_exists='append', 
                            index=False, method='multi', chunksize=100)
            
            self.conn.commit()
            
            result = {
                'success': True,
                'count': len(df),
                'message': f'保存成功: {len(df)}条股票日线数据'
            }
            
            logger.info(f"股票日线数据保存完成: {result}")
            return result
            
        except Exception as e:
            self.conn.rollback()
            logger.error(f"保存股票日线数据失败: {e}", exc_info=True)
            return {'success': False, 'message': str(e)}
    
    def get_stock_daily(self, code: Optional[str] = None,
                      date: Optional[str] = None,
                      limit: Optional[int] = None) -> pd.DataFrame:
        """
        获取股票日线数据
        
        Args:
            code: 股票代码（可选）
            date: 日期（可选）
            limit: 返回条数限制（可选）
            
        Returns:
            股票日线数据DataFrame
        """
        self.connect()
        cursor = self.conn.cursor()
        
        query = 'SELECT * FROM stock_daily WHERE 1=1'
        params = []
        
        if code:
            query += ' AND code = ?'
            params.append(code)
        
        if date:
            query += ' AND date = ?'
            params.append(date)
        
        query += ' ORDER BY date DESC'
        
        if limit:
            query += ' LIMIT ?'
            params.append(limit)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        if rows:
            df = pd.DataFrame(rows)
            columns = [desc[0] for desc in cursor.description]
            df.columns = columns
            return df
        else:
            return pd.DataFrame()
    
    def save_factor_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        保存因子数据
        
        Args:
            df: 因子数据DataFrame
            
        Returns:
            保存结果统计
        """
        if df.empty:
            return {'success': False, 'message': '数据为空'}
        
        self.connect()
        cursor = self.conn.cursor()
        
        try:
            # 处理缺失列
            save_columns = ['code', 'date', 'ma5', 'ma10', 'ma20', 'ma60',
                         'macd_dif', 'macd_dea', 'macd_hist',
                         'rsi', 'boll_up', 'boll_mid', 'boll_down']
            
            df_to_save = pd.DataFrame()
            for col in save_columns:
                if col in df.columns:
                    df_to_save[col] = df[col]
                else:
                    df_to_save[col] = None
            
            df_to_save.to_sql('factor_data', self.conn, if_exists='append', 
                            index=False, method='multi')
            
            self.conn.commit()
            
            result = {
                'success': True,
                'count': len(df),
                'message': f'保存成功: {len(df)}条因子数据'
            }
            
            logger.info(f"因子数据保存完成: {result}")
            return result
            
        except Exception as e:
            self.conn.rollback()
            logger.error(f"保存因子数据失败: {e}", exc_info=True)
            return {'success': False, 'message': str(e)}
    
    def get_factor_data(self, code: Optional[str] = None,
                      date: Optional[str] = None) -> pd.DataFrame:
        """
        获取因子数据
        
        Args:
            code: 股票代码（可选）
            date: 日期（可选）
            
        Returns:
            因子数据DataFrame
        """
        self.connect()
        cursor = self.conn.cursor()
        
        query = 'SELECT * FROM factor_data WHERE 1=1'
        params = []
        
        if code:
            query += ' AND code = ?'
            params.append(code)
        
        if date:
            query += ' AND date = ?'
            params.append(date)
        
        query += ' ORDER BY date DESC'
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        if rows:
            df = pd.DataFrame(rows)
            columns = [desc[0] for desc in cursor.description]
            df.columns = columns
            return df
        else:
            return pd.DataFrame()
    
    def get_latest_date(self, code: Optional[str] = None) -> Optional[str]:
        """
        获取最新数据日期
        
        Args:
            code: 股票代码（可选）
            
        Returns:
            最新日期字符串
        """
        self.connect()
        cursor = self.conn.cursor()
        
        if code:
            cursor.execute('''
                SELECT MAX(date) FROM stock_daily WHERE code = ?
            ''', (code,))
        else:
            cursor.execute('SELECT MAX(date) FROM stock_daily')
        
        result = cursor.fetchone()
        
        if result and result[0]:
            return result[0]
        else:
            return None


# 全局数据管理器实例
_data_manager_instance = None

def get_data_manager() -> DataManager:
    """
    获取数据管理器单例
    
    Returns:
        DataManager实例
    """
    global _data_manager_instance
    if _data_manager_instance is None:
        _data_manager_instance = DataManager()
    return _data_manager_instance