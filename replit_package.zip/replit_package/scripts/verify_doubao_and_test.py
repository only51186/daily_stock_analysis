# -*- coding: utf-8 -*-
"""
===================================
豆包 API Key 验证和测试推送脚本
===================================

【功能】
1. 验证豆包 API Key 是否有效
2. 测试 API 调用是否正常
3. 发送测试推送消息

【使用方法】
直接运行此脚本：
    python verify_doubao_and_test.py
"""

import os
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv


def print_banner():
    """
    打印横幅
    """
    banner = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                      ║
║          🔑 豆包 API Key 验证和测试推送 🔑                          ║
║                                                                      ║
╚════════════════════════════════════════════════════════════════════╝
"""
    print(banner)


def verify_doubao_api_key():
    """
    验证豆包 API Key
    """
    print("=" * 80)
    print("【步骤 1/3】验证豆包 API Key")
    print("=" * 80)
    
    # 加载 .env 文件
    env_path = Path(__file__).parent.parent / '.env'
    load_dotenv(env_path)
    
    doubao_api_key = os.getenv('DOUBAO_API_KEY', '').strip()
    
    print(f"\nAPI Key 状态检查...")
    print(f"  原始值: {repr(os.getenv('DOUBAO_API_KEY'))}")
    print(f"  去空格后: {repr(doubao_api_key)}")
    
    if not doubao_api_key or doubao_api_key == '':
        print(f"\n❌ 豆包 API Key 未配置")
        return False
    
    print(f"\n✅ 豆包 API Key 已配置")
    print(f"  长度: {len(doubao_api_key)} 字符")
    print(f"  前20字符: {doubao_api_key[:20]}")
    print(f"  后10字符: {doubao_api_key[-10:]}")
    
    return True


def test_api_connection():
    """
    测试 API 连接
    """
    print("\n" + "=" * 80)
    print("【步骤 2/3】测试 API 连接")
    print("=" * 80)
    
    doubao_api_key = os.getenv('DOUBAO_API_KEY', '').strip()
    api_url = os.getenv('DOUBAO_API_URL', 'https://ark.cn-beijing.volces.com/api/v3/chat/completions')
    model = os.getenv('DOUBAO_MODEL', 'Doubao-Seedream-5.0-lite')
    
    print(f"\nAPI 配置信息:")
    print(f"  API URL: {api_url}")
    print(f"  模型: {model}")
    
    print(f"\n正在测试 API 连接...")
    
    try:
        import requests
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {doubao_api_key}'
        }
        
        payload = {
            'model': model,
            'messages': [
                {
                    'role': 'user',
                    'content': '测试连接，请回复"连接成功"'
                }
            ],
            'max_tokens': 10
        }
        
        response = requests.post(api_url, headers=headers, json=payload, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            print(f"\n✅ API 连接成功")
            print(f"  响应状态: {response.status_code}")
            print(f"  响应内容: {result.get('choices', [{}])[0].get('message', {}).get('content', 'N/A')}")
            return True
        else:
            print(f"\n❌ API 连接失败")
            print(f"  响应状态: {response.status_code}")
            print(f"  错误信息: {response.text[:200]}")
            return False
            
    except Exception as e:
        print(f"\n❌ API 连接失败")
        print(f"  错误信息: {str(e)[:200]}")
        return False


def send_test_notification():
    """
    发送测试推送
    """
    print("\n" + "=" * 80)
    print("【步骤 3/3】发送测试推送")
    print("=" * 80)
    
    doubao_api_key = os.getenv('DOUBAO_API_KEY', '').strip()
    api_url = os.getenv('DOUBAO_API_URL', 'https://ark.cn-beijing.volces.com/api/v3/chat/completions')
    model = os.getenv('DOUBAO_MODEL', 'Doubao-Seedream-5.0-lite')
    
    print(f"\n正在发送测试推送...")
    
    try:
        import requests
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {doubao_api_key}'
        }
        
        # 测试推送消息
        test_message = """
【股票量化自动化系统】

✅ API 配置成功，自动推送功能已就绪

系统信息：
- 配置时间: {timestamp}
- 系统版本: v1.0
- 通知状态: 已启用

后续将自动推送：
- 尾盘选股结果
- 历史回测报告
- 市场复盘日报

系统已准备就绪，可以开始使用！
        """.format(timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        payload = {
            'model': model,
            'messages': [
                {
                    'role': 'user',
                    'content': test_message
                }
            ],
            'max_tokens': 500
        }
        
        response = requests.post(api_url, headers=headers, json=payload, timeout=10)
        
        if response.status_code == 200:
            print(f"\n✅ 测试推送发送成功")
            print(f"  请检查您的豆包消息，应该已收到测试通知")
            return True
        else:
            print(f"\n❌ 测试推送发送失败")
            print(f"  响应状态: {response.status_code}")
            print(f"  错误信息: {response.text[:200]}")
            return False
            
    except Exception as e:
        print(f"\n❌ 测试推送发送失败")
        print(f"  错误信息: {str(e)[:200]}")
        return False


def main():
    """
    主函数
    """
    print_banner()
    
    print(f"\n开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 步骤1: 验证 API Key
    if not verify_doubao_api_key():
        print("\n" + "=" * 80)
        print("❌ 配置失败")
        print("=" * 80)
        print("\n豆包 API Key 未配置")
        return
    
    # 步骤2: 测试 API 连接
    if not test_api_connection():
        print("\n" + "=" * 80)
        print("❌ 配置失败")
        print("=" * 80)
        print("\nAPI 连接测试失败，请检查：")
        print("  1. API Key 是否正确")
        print("  2. 网络连接是否正常")
        print("  3. 豆包服务是否可用")
        return
    
    # 步骤3: 发送测试推送
    if not send_test_notification():
        print("\n" + "=" * 80)
        print("❌ 配置失败")
        print("=" * 80)
        print("\n测试推送发送失败")
        return
    
    # 成功总结
    print("\n" + "=" * 80)
    print("🎉 配置成功！")
    print("=" * 80)
    print("\n✅ 豆包 API Key 配置完成")
    print("✅ API 连接测试通过")
    print("✅ 测试推送已发送")
    print("\n自动推送功能已就绪，后续将自动推送：")
    print("  - 尾盘选股结果（每日 18:00）")
    print("  - 历史回测报告（每日 20:00）")
    print("  - 市场复盘日报（每日 21:00）")
    print("\n下一步：启动自动化系统")
    print("  命令: python main.py --mode schedule")
    print("=" * 80)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n已中断")
    except Exception as e:
        print(f"\n❌ 异常: {e}")
        import traceback
        traceback.print_exc()
