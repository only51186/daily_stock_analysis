# -*- coding: utf-8 -*-
"""
===================================
API密钥配置验证脚本
===================================

【功能】
验证 .env 文件中的 API 密钥是否配置正确

【使用方法】
填完密钥后，直接运行此脚本：
    python verify_config.py
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv


def verify_config():
    """
    验证配置
    """
    print("=" * 80)
    print("API密钥配置验证")
    print("=" * 80)
    
    # 加载 .env 文件
    env_path = Path(__file__).parent.parent / '.env'
    load_dotenv(env_path)
    
    # 检查 Tushare Token
    tushare_token = os.getenv('TUSHARE_TOKEN', '').strip()
    
    print("\n1. Tushare Token 检查")
    print("-" * 80)
    if tushare_token and tushare_token != '':
        print(f"✅ Tushare Token 已配置")
        print(f"   Token: {tushare_token[:20]}...{tushare_token[-10:]}")
        
        # 测试连接
        try:
            import tushare as ts
            pro = ts.pro_api(tushare_token)
            df = pro.trade_cal(exchange='SSE', start_date='20260301', end_date='20260303')
            print(f"✅ Tushare 连接成功，获取到 {len(df)} 条交易日数据")
        except Exception as e:
            print(f"❌ Tushare 连接失败: {str(e)[:100]}")
            print(f"   请检查 Token 是否正确")
    else:
        print(f"❌ Tushare Token 未配置")
        print(f"   请在 .env 文件中填入 TUSHARE_TOKEN")
        print(f"   获取地址: https://tushare.pro/register")
    
    # 检查豆包 API Key
    doubao_api_key = os.getenv('DOUBAO_API_KEY', '').strip()
    
    print("\n2. 豆包 API Key 检查")
    print("-" * 80)
    if doubao_api_key and doubao_api_key != '':
        print(f"✅ 豆包 API Key 已配置")
        print(f"   API Key: {doubao_api_key[:20]}...{doubao_api_key[-10:]}")
        
        # 测试连接
        try:
            import requests
            api_url = os.getenv('DOUBAO_API_URL', 'https://ark.cn-beijing.volces.com/api/v3/chat/completions')
            model = os.getenv('DOUBAO_MODEL', 'Doubao-Seedream-5.0-lite')
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {doubao_api_key}'
            }
            
            payload = {
                'model': model,
                'messages': [
                    {
                        'role': 'user',
                        'content': '测试连接'
                    }
                ],
                'max_tokens': 10
            }
            
            response = requests.post(api_url, headers=headers, json=payload, timeout=10)
            
            if response.status_code == 200:
                print(f"✅ 豆包 API 连接成功")
            else:
                print(f"❌ 豆包 API 连接失败: {response.status_code}")
                print(f"   请检查 API Key 是否正确")
        except Exception as e:
            print(f"❌ 豆包 API 连接失败: {str(e)[:100]}")
            print(f"   请检查 API Key 是否正确")
    else:
        print(f"❌ 豆包 API Key 未配置")
        print(f"   请在 .env 文件中填入 DOUBAO_API_KEY")
        print(f"   获取地址: https://console.volcengine.com/ark")
    
    # 总结
    print("\n" + "=" * 80)
    print("验证总结")
    print("=" * 80)
    
    if tushare_token and doubao_api_key:
        print("✅ 所有 API 密钥已配置，可以开始使用系统")
        print("\n下一步：运行单次测试脚本")
        print("  python test_single_run.py")
    else:
        print("❌ 部分 API 密钥未配置，请先完成配置")
        print("\n获取密钥步骤：")
        print("  1. Tushare Token: https://tushare.pro/register")
        print("  2. 豆包 API Key: https://console.volcengine.com/ark")
    
    print("=" * 80)


if __name__ == '__main__':
    verify_config()
